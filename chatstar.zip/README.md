# ChatStar

Site web simple pour converser avec une célébrité simulée par une IA.
    
- Choix de célébrités populaires ou possibilité d’en ajouter une.
- Conversation style WhatsApp.
- IA répond en simulant la célébrité (demo basique).

## Installation

- Crée un repo GitHub vide
- Upload les fichiers (index.html, style.css, script.js, README.md)
- Connecte à Vercel et ajoute ta clé OpenAI pour la vraie IA